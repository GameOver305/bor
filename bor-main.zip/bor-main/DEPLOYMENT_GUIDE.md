# 🚀 دليل النشر والاستضافة الشامل
# Comprehensive Deployment Guide

<div dir="rtl">

## 📋 نظرة عامة

هذا الدليل يشرح كيفية نشر وتحديث بوت Discord على مختلف منصات الاستضافة، مع التركيز على **WispByte** والمنصات الأخرى التي لا توفر Console مباشر.

---

## 🎯 الأنواع الثلاثة للنشر

### 1. النشر الأول (First Deployment)
- رفع جميع ملفات المشروع
- إعداد البيئة والإعدادات
- إنشاء قاعدة البيانات

### 2. التحديث (Update)
- رفع الملفات المحدثة فقط
- الحفاظ على البيانات الموجودة
- تطبيق التحديثات على قاعدة البيانات

### 3. الصيانة (Maintenance)
- النسخ الاحتياطي
- استكشاف الأخطاء
- مراقبة الأداء

---

## 🌐 WispByte - الدليل الكامل

### ✅ المميزات
- استضافة Discord Bots مجانية
- لوحة تحكم سهلة الاستخدام
- File Manager لرفع الملفات
- Terminal (Console) محدود أو غير متاح

### 📁 النشر الأول على WispByte

#### الخطوة 1: تحضير الملفات
قبل الرفع، تأكد من وجود جميع الملفات:

**✅ الملفات المطلوبة:**
```
bor/
├── bot.py
├── config.py
├── requirements.txt
├── .env
│
├── cogs/
│   ├── __init__.py
│   ├── admin.py
│   ├── admin_panel.py
│   ├── alliance.py
│   ├── alliance_advanced.py
│   ├── bookings.py
│   ├── help.py
│   ├── main_menu.py
│   ├── permissions_manager.py
│   └── stats.py
│
├── database/
│   ├── __init__.py
│   ├── db_manager.py
│   ├── models.py
│   ├── schema.sql
│   ├── schema_v2.sql
│   └── migrations/
│       ├── migrate_to_v2.py
│       ├── add_new_fields.py
│       └── add_permissions_system.py
│
├── utils/
│   ├── __init__.py
│   ├── datetime_helper.py
│   ├── embeds.py
│   ├── formatters.py
│   ├── permissions.py
│   └── validators.py
│
└── tasks/
    ├── __init__.py
    ├── backup_task.py
    ├── cleanup_task.py
    └── reminders_task.py
```

#### الخطوة 2: إعداد ملف .env
قم بإنشاء ملف `.env` مع الإعدادات الخاصة بك:

```env
# Discord Bot Token
DISCORD_BOT_TOKEN=YOUR_BOT_TOKEN_HERE

# Server Configuration
GUILD_ID=YOUR_SERVER_ID

# Role IDs
ADMIN_ROLE_ID=123456789
MODERATOR_ROLE_ID=987654321

# Channel IDs  
LOG_CHANNEL_ID=YOUR_LOG_CHANNEL
ANNOUNCEMENT_CHANNEL_ID=YOUR_ANNOUNCEMENT_CHANNEL

# Bot Settings
MAX_ACTIVE_BOOKINGS=5
LANGUAGE=ar
TIMEZONE=Asia/Riyadh

# Points Configuration
POINTS_COMPLETED=10
POINTS_ON_TIME=5
POINTS_CANCELLED=-5

# Reminders
REMINDER_24H=true
REMINDER_1H=true
REMINDER_NOW=true

# Backup
AUTO_BACKUP_HOURS=6
```

#### الخطوة 3: رفع الملفات عبر File Manager

1. **تسجيل الدخول لـ WispByte**
   - افتح لوحة التحكم
   - اذهب لـ File Manager

2. **إنشاء المجلدات الفارغة**
   قبل رفع الملفات، أنشئ المجلدات التالية:
   ```
   data/
   data/backups/
   logs/
   ```

3. **رفع الملفات الرئيسية**
   - ارفع `bot.py`
   - ارفع `config.py`
   - ارفع `requirements.txt`
   - ارفع `.env` (تأكد من أنه يحتوي على Token صحيح)

4. **رفع المجلدات**
   - ارفع مجلد `cogs/` كامل
   - ارفع مجلد `database/` كامل
   - ارفع مجلد `utils/` كامل
   - ارفع مجلد `tasks/` كامل

#### الخطوة 4: تثبيت المتطلبات

إذا كان لديك Terminal:
```bash
pip install -r requirements.txt
```

إذا لم يكن لديك Terminal:
- استخدم خيار "Install Requirements" في لوحة التحكم
- أو أخبر الدعم الفني لتثبيت المتطلبات

#### الخطوة 5: تشغيل البوت

1. في لوحة تحكم WispByte:
   - اذهب لـ "Startup"
   - تأكد أن الأمر هو: `python bot.py`
   - احفظ التغييرات

2. اضغط "Start" لتشغيل البوت

3. راقب Console Logs للتأكد من عدم وجود أخطاء

#### الخطوة 6: التحقق من النجاح

✅ **علامات النجاح:**
- البوت يظهر Online في Discord
- الأوامر `/start` و `/menu` و `/help` تعمل
- يمكنك إنشاء حجز جديد
- التذكيرات تعمل

---

## 🔄 تحديث البوت على WispByte

### 📋 قبل التحديث

**⚠️ مهم جداً - لا تحذف:**
- مجلد `data/` (قاعدة البيانات)
- ملف `.env` (الإعدادات)
- مجلد `logs/` (السجلات)

### 📝 خطوات التحديث

#### 1. إيقاف البوت
- في لوحة التحكم، اضغط "Stop"
- انتظر حتى يتوقف كاملاً

#### 2. عمل نسخة احتياطية

**طريقة 1: من File Manager**
1. حمّل مجلد `data/` كامل لجهازك
2. حمّل ملف `.env` لجهازك

**طريقة 2: إذا كان Terminal متاح**
```bash
cp -r data/ data_backup_$(date +%Y%m%d)/
cp .env .env.backup
```

#### 3. رفع الملفات المحدثة

**✅ الملفات التي يجب تحديثها:**

📄 **الملفات الرئيسية:**
- `bot.py` - إذا تم تحديثه
- `config.py` - إذا تم تحديثه
- `requirements.txt` - إذا أضيفت مكتبات جديدة

📁 **المجلدات:**
- `cogs/` - جميع الملفات (الجديدة والمحدثة)
- `database/` - الملفات المحدثة فقط
- `utils/` - الملفات المحدثة فقط
- `tasks/` - الملفات المحدثة فقط

**❌ لا ترفع/تحذف:**
- مجلد `data/` (قاعدة البيانات الموجودة)
- ملف `.env` (إلا إذا كنت تريد تحديث الإعدادات)
- مجلد `logs/` (السجلات القديمة)

#### 4. تطبيق تحديثات قاعدة البيانات (إذا لزم الأمر)

إذا كان التحديث يتطلب ترقية قاعدة البيانات:

**طريقة 1: باستخدام Terminal**
```bash
python database/migrations/migrate_to_v2.py
```

**طريقة 2: بدون Terminal**
1. اطلب من الدعم الفني تشغيل الأمر
2. أو انتظر - البوت سيطبق التحديثات تلقائياً عند التشغيل

#### 5. تحديث المتطلبات (إذا لزم الأمر)

إذا تم تحديث `requirements.txt`:

**مع Terminal:**
```bash
pip install -r requirements.txt --upgrade
```

**بدون Terminal:**
- استخدم خيار "Reinstall Dependencies" في لوحة التحكم

#### 6. إعادة تشغيل البوت

1. في لوحة التحكم، اضغط "Start"
2. راقب Console Logs
3. تأكد من عدم وجود أخطاء

#### 7. اختبار التحديثات

في Discord، قم باختبار:
```
/start    - يجب أن يعمل
/menu     - يجب أن يعمل
/help     - يجب أن يعمل
/حجز      - اختبار إنشاء حجز
/مواعيدي  - عرض الحجوزات
```

### 🔧 إذا حدثت مشاكل بعد التحديث

#### المشكلة: البوت لا يعمل

**الحل:**
1. أوقف البوت
2. راجع Console Logs للأخطاء
3. تأكد من أن ملف `.env` موجود وصحيح
4. تأكد من رفع جميع الملفات المطلوبة

#### المشكلة: الأوامر لا تظهر

**الحل:**
```python
# في bot.py، تأكد من وجود هذا الكود:
await self.tree.sync()
```

#### المشكلة: قاعدة البيانات لا تعمل

**الحل:**
1. تأكد من وجود مجلد `data/`
2. تأكد من أن `data/bookings.db` موجود
3. إذا لزم الأمر، استرجع النسخة الاحتياطية

---

## 🐳 Docker Deployment

### البناء والتشغيل

```bash
# بناء الصورة
docker build -t booking-bot .

# تشغيل الحاوية
docker run -d \
  --name booking-bot \
  -v $(pwd)/data:/app/data \
  -v $(pwd)/logs:/app/logs \
  --env-file .env \
  booking-bot
```

### مع Docker Compose

```bash
# تشغيل
docker-compose up -d

# إيقاف
docker-compose down

# إعادة التشغيل
docker-compose restart

# عرض السجلات
docker-compose logs -f
```

---

## 🖥️ VPS / Cloud Server Deployment

### Ubuntu / Debian

```bash
# 1. تثبيت Python
sudo apt update
sudo apt install python3 python3-pip git -y

# 2. استنساخ المشروع
git clone https://github.com/Dnager1/bor.git
cd bor

# 3. تثبيت المتطلبات
pip3 install -r requirements.txt

# 4. إعداد .env
cp .env.example .env
nano .env  # أضف Token والإعدادات

# 5. تشغيل البوت
python3 bot.py
```

### استخدام systemd للتشغيل التلقائي

```bash
# إنشاء ملف الخدمة
sudo nano /etc/systemd/system/booking-bot.service
```

محتوى الملف:
```ini
[Unit]
Description=Discord Booking Bot
After=network.target

[Service]
Type=simple
User=YOUR_USERNAME
WorkingDirectory=/path/to/bor
ExecStart=/usr/bin/python3 /path/to/bor/bot.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

تفعيل الخدمة:
```bash
sudo systemctl daemon-reload
sudo systemctl enable booking-bot
sudo systemctl start booking-bot
sudo systemctl status booking-bot
```

---

## 🔍 استكشاف الأخطاء الشائعة

### 1. البوت لا يستجيب للأوامر

**الأسباب المحتملة:**
- الأوامر غير مزامنة
- صلاحيات البوت غير كافية
- Bot Token خاطئ

**الحلول:**
```python
# تأكد من وجود هذا في bot.py
await self.tree.sync()
```

### 2. خطأ في قاعدة البيانات

**الأسباب:**
- مجلد `data/` غير موجود
- صلاحيات الكتابة غير متاحة

**الحلول:**
```bash
mkdir -p data logs
chmod 755 data logs
```

### 3. المكتبات مفقودة

**الحل:**
```bash
pip install -r requirements.txt --upgrade
```

### 4. التذكيرات لا تعمل

**تحقق من:**
- إعدادات التذكير في `.env`
- صلاحيات إرسال DM للمستخدمين
- السجلات في `logs/errors.log`

---

## 📊 مراقبة الأداء

### السجلات المهمة

```bash
# السجل الرئيسي
tail -f logs/bot.log

# سجل الأخطاء
tail -f logs/errors.log

# سجل الحجوزات
tail -f logs/bookings.log
```

### النسخ الاحتياطي التلقائي

البوت يقوم بنسخ احتياطي كل 6 ساعات في:
```
data/backups/backup_YYYYMMDD_HHMMSS.db
```

### النسخ الاحتياطي اليدوي

```bash
# نسخة سريعة
cp data/bookings.db data/backups/manual_backup_$(date +%Y%m%d).db

# نسخة كاملة
tar -czf backup_full_$(date +%Y%m%d).tar.gz data/ logs/ .env
```

---

## 🔐 الأمان

### ✅ أفضل الممارسات

1. **لا تشارك ملف `.env` أبداً**
2. **استخدم صلاحيات محدودة للبوت**
3. **راجع السجلات بانتظام**
4. **احتفظ بنسخ احتياطية**
5. **حدّث المكتبات بانتظام**

### تحديث المكتبات

```bash
pip install -r requirements.txt --upgrade
```

---

## 📞 الدعم والمساعدة

### إذا واجهت مشاكل:

1. **راجع السجلات**
   ```bash
   tail -n 100 logs/errors.log
   ```

2. **تحقق من Console Output**
   - في WispByte: راجع Console
   - في VPS: راجع systemd logs

3. **راجع UPDATE_CHECKLIST.md**
   - تأكد من إكمال جميع الخطوات

4. **اطلب المساعدة**
   - افتح Issue في GitHub
   - راجع التوثيق
   - اتصل بدعم الاستضافة

---

## ✅ Checklist للنشر الناجح

### النشر الأول:
- [ ] رفع جميع الملفات
- [ ] إنشاء مجلدات `data/` و `logs/`
- [ ] إعداد ملف `.env` بشكل صحيح
- [ ] تثبيت المتطلبات
- [ ] تشغيل البوت
- [ ] اختبار الأوامر الأساسية
- [ ] التحقق من التذكيرات

### التحديث:
- [ ] عمل نسخة احتياطية
- [ ] إيقاف البوت
- [ ] رفع الملفات المحدثة فقط
- [ ] عدم حذف `data/` و `.env`
- [ ] تطبيق ترقية قاعدة البيانات (إذا لزم)
- [ ] تحديث المتطلبات (إذا لزم)
- [ ] إعادة تشغيل البوت
- [ ] اختبار جميع الوظائف
- [ ] التحقق من السجلات

---

## 🎉 الخاتمة

باتباع هذا الدليل، يمكنك نشر وتحديث البوت بنجاح على أي منصة استضافة، خاصةً **WispByte** والمنصات الأخرى التي لا توفر Console مباشر.

**تذكر:**
- احتفظ دائماً بنسخ احتياطية
- لا تحذف مجلد `data/`
- راجع السجلات عند وجود مشاكل
- اختبر التحديثات في بيئة تجريبية أولاً

---

Made with ❤️ for Discord Bot Developers

</div>
