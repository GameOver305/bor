"""
نظام اللغات - Languages System
"""
