# 📖 دليل التثبيت - بوت مواعيد النجاة في الصقيع

<div dir="rtl">

## 📋 المتطلبات الأساسية

قبل البدء، تأكد من توفر:

### 1. Python 3.8 أو أحدث
تحقق من الإصدار:
```bash
python --version
```

إذا لم يكن مثبتاً، حمله من [python.org](https://www.python.org/downloads/)

### 2. Git
```bash
git --version
```

### 3. Discord Bot Token
- اذهب إلى [Discord Developer Portal](https://discord.com/developers/applications)
- أنشئ تطبيق جديد
- اذهب إلى قسم "Bot"
- انقر على "Add Bot"
- انسخ Token

## 🚀 خطوات التثبيت

### الخطوة 1: تحميل المشروع

```bash
# استنساخ المستودع
git clone https://github.com/Dnager1/bor.git

# الانتقال لمجلد المشروع
cd bor
```

### الخطوة 2: إنشاء بيئة افتراضية (اختياري ولكن موصى به)

**Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

**Linux/Mac:**
```bash
python3 -m venv venv
source venv/bin/activate
```

### الخطوة 3: تثبيت المكتبات

```bash
pip install -r requirements.txt
```

### الخطوة 4: إعداد ملف البيئة

```bash
# نسخ ملف المثال
cp .env.example .env
```

افتح ملف `.env` وعدل القيم:

```env
# === ضروري ===
DISCORD_BOT_TOKEN=your_actual_bot_token_here

# === للحصول على معرف السيرفر ===
# 1. فعّل وضع المطور في Discord (الإعدادات > متقدم > وضع المطور)
# 2. انقر بزر الماوس الأيمن على السيرفر > نسخ المعرف
GUILD_ID=your_server_id

# === معرفات الأدوار (اختياري) ===
# انقر بزر الماوس الأيمن على الدور > نسخ المعرف
ADMIN_ROLE_ID=123456789
MODERATOR_ROLE_ID=987654321

# === معرفات القنوات (اختياري) ===
LOG_CHANNEL_ID=your_log_channel_id
ANNOUNCEMENT_CHANNEL_ID=your_announcement_channel_id

# === الإعدادات ===
MAX_ACTIVE_BOOKINGS=5
LANGUAGE=ar
TIMEZONE=Asia/Riyadh

# === التذكيرات ===
REMINDER_24H=true
REMINDER_1H=true
REMINDER_NOW=true

# === النسخ الاحتياطي ===
AUTO_BACKUP_HOURS=6
```

### الخطوة 5: إعداد صلاحيات البوت

1. اذهب إلى [Discord Developer Portal](https://discord.com/developers/applications)
2. اختر تطبيقك
3. اذهب إلى قسم "OAuth2" > "URL Generator"
4. اختر:
   - **Scopes:** `bot`, `applications.commands`
   - **Bot Permissions:**
     - Send Messages
     - Send Messages in Threads
     - Embed Links
     - Attach Files
     - Read Message History
     - Use Slash Commands
     - Manage Messages (اختياري)

5. انسخ الرابط المولّد وافتحه لدعوة البوت

### الخطوة 6: تشغيل البوت

```bash
python bot.py
```

### الخطوة 7: التحقق من التشغيل

عند تشغيل البوت بنجاح، ستظهر رسائل مثل:

```
INFO - 🔧 بدء إعداد البوت...
INFO - ✅ تم تهيئة قاعدة البيانات
INFO - ✅ تم تحميل cogs.bookings
INFO - ✅ تم تحميل cogs.admin
INFO - ✅ تم تحميل cogs.stats
INFO - ✅ تم تحميل cogs.alliance
INFO - ✅ تم تحميل cogs.help
INFO - ✅ تم مزامنة الأوامر للسيرفر
INFO - ✅ البوت جاهز!
```

### الخطوة 8: اختبار الأوامر

في Discord، جرب:
```
/help
```

يجب أن يستجيب البوت بدليل المساعدة.

## 🐳 التثبيت باستخدام Docker (قريباً)

```bash
# بناء الصورة
docker build -t bor-bot .

# تشغيل الحاوية
docker-compose up -d
```

## 🔧 استكشاف المشاكل

### المشكلة: "Module not found"
```bash
# تأكد من تثبيت كل المكتبات
pip install -r requirements.txt --upgrade
```

### المشكلة: "Invalid Token"
- تأكد من نسخ Token بشكل صحيح
- تأكد من عدم وجود مسافات في البداية أو النهاية
- أعد إنشاء Token من Developer Portal

### المشكلة: "Privileged intent not enabled"
1. اذهب إلى Developer Portal
2. قسم "Bot"
3. فعّل "Server Members Intent" و "Message Content Intent"

### المشكلة: "Commands not syncing"
```bash
# امسح cache الأوامر
# أعد تشغيل البوت
# انتظر حتى دقيقة واحدة
```

### المشكلة: البوت يعمل ولكن لا يستجيب
- تأكد من صلاحيات البوت في السيرفر
- تأكد من أن `GUILD_ID` صحيح
- تحقق من سجلات الأخطاء في `logs/errors.log`

## 📊 التحقق من قاعدة البيانات

بعد أول تشغيل، تحقق من:
```bash
# يجب أن يوجد ملف قاعدة البيانات
ls data/bookings.db
```

## 🔄 التحديث

```bash
# سحب آخر التحديثات
git pull origin main

# تحديث المكتبات
pip install -r requirements.txt --upgrade

# إعادة تشغيل البوت
python bot.py
```

## 🛑 إيقاف البوت

- اضغط `Ctrl + C` في Terminal
- أو أغلق نافذة Terminal

## 🔐 نصائح الأمان

1. **لا تشارك `.env` أبداً**
2. **لا تشارك Bot Token**
3. **استخدم `.gitignore` لحماية الملفات الحساسة**
4. **فعّل 2FA على حساب Discord**
5. **قلل صلاحيات البوت للحد الأدنى**

## 📝 الخطوات التالية

بعد التثبيت الناجح:

1. ✅ اقرأ [دليل الاستخدام](COMMANDS.md)
2. ✅ جرب إنشاء حجز باستخدام `/حجز`
3. ✅ عدّل الإعدادات في `.env` حسب احتياجاتك
4. ✅ أنشئ تحالفك باستخدام `/alliance create`
5. ✅ استكشف أوامر الإدارة `/admin`

## 🆘 الحصول على المساعدة

إذا واجهت مشاكل:

1. تحقق من `logs/errors.log`
2. تحقق من [الأسئلة الشائعة](docs/FAQ.md)
3. افتح [Issue على GitHub](https://github.com/Dnager1/bor/issues)

## 🎉 تهانينا!

البوت الآن يعمل ويستقبل الأوامر! 🚀

---

**ملاحظة:** للتشغيل على خادم 24/7، ضع في اعتبارك:
- استخدام VPS (Digital Ocean, AWS, etc.)
- استخدام خدمة استضافة بوتات Discord
- تشغيل كخدمة نظام (systemd على Linux)

</div>
